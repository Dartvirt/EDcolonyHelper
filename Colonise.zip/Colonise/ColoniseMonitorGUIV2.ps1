﻿using namespace System.Windows.Forms
add-type -AssemblyName  System.Windows.Forms
$scriptpath =$MyInvocation.MyCommand.Path
if ($scriptpath -eq $null) {$homedir = "C:\data\Scripts\Colonise\"} else {$homedir = (split-path $scriptpath )+ "\"}
$templateDir = "$homedir\templates\"
$progressfile = $homedir+"Progress.csvBAD"   # not using, but dont want to trash old one by accident
$progressfileNew = $homedir+"Progress.csvBAD"
$DefaultcargoSize = 700
$LargePadCargosize = 400  # change this to suit your cargo ships. ships with cargo capacity above this value and Inara buy search will be set to large pad only, otherwise medium or larger
$GLOBAL:cargoSize = $DefaultcargoSize
$progressDir = $homedir+"Progress\" 
$carrierfile = $progressDir+"_carrier.json"
$shipfile = $progressDir+"_ship.json"
$GLOBAL:depotName = $null
$statusfile = $homedir+"statusV2.json"
$marketfile = $homedir+"market.json"
 $lastWrite = $null
 $lastStatus = $null
 $lastMarket = $null

$marketData= $null

$inaraTEMPLATE = "https://inara.cz/elite/commodities/?formbrief=1&pi10=3&pi11=0&pi9=0&pi4=0&pi14=0&pi5=720&pi12=0&pi7=0&pi8=0&pi13=1"

$lookupID = get-content C:\data\Scripts\Colonise\InaraCommodities.csv |convertFrom-csv

class TprogressRow {
[string]$name
[string]$type
[int64]$ship
[int64]$Required
[int64]$Delivered
[int64]$Carrier
[int64]$Remaining

}
class Tcommodity {
[string]$Name
[string]$Type
[INT64]$Required
[INT64]$Have
}


function search-inara ($action,$commodity,$pad,$System) {

    $action = "&pi1=$action"
    $system = "&ps1=$system"
    $pad = "&pi3=$pad"

    if ($system -ne $null) {$ID = ($lookupID |where {$_.commodity -ieq $Commodity}).id;$ID = "&pa1[]=$ID" } else {$ID = ""}

    $url = $inaraTEMPLATE + $action + $ID + $system + $pad
    Start-Process $URL

}
function change-depot {
  $Statusjson = get-content $statusFile
  $status = convertfrom-json "$StatusJson"
  $newDepot= $table.depotchooser.SelectedItem
  if ($newdepot -ine  $status.activeDepot) {
     $status.activeDepot = $newDepot
     $GLOBAL:depotName = $newDepot
     $GLOBAL:proghash = load-progress
     load_data 
      Write-host CHANGE DEPOT TO ($status.activeDepot)
      $Statusjson = $status | ConvertTo-json
      $Statusjson | set-content $statusFile -force
      }
}

function copyToClipboard {

$text = $table.LVtable.SelectedItems[0].Text
write-host $text
Set-Clipboard $text
if ($cargosize -gt $LargePadCargosize) {$pad = 3} else {$pad = 2}
search-inara 1 $text $pad $GLOBAL:StarSystem
}

function sum($a) {
    $S= 0
    $a |foreach {$S = $S + $_}
    $s
    }

class TStatus {
[string]$heartbeat
[string]$comment
}

function remove-hash ($loc) {
    $values = $loc.hash.values
    $loc.commodities = $values |sort type
    $loc |select name,kind,comment,registration,commodities
}

function save-location ($location) {
    $loc = remove-hash $location
    $json = $loc|convertTo-json
    $fname = $progressDir + $location.name + ".json"
    $json |out-file $fname
}

function save-progress {
    save-location $Global:depot
    save-location $Global:carrier
    save-location $Global:ship
}

function add-hash ($loc) {
    $hash = [hashtable]::new()
    $loc.commodities |foreach {$hash.add($_.type,$_)}
    $loc |add-member -MemberType NoteProperty -Name hash -value $hash
    $loc
}

function load-location ($Dname) {
   if ($Dname -ne $null) {
        $fname = $carrierfile = $progressDir+$Dname+".json"
        $json = get-content $fname 
        $location = convertfrom-json "$json"
        $location = add-hash $location
        $location.name = $Dname
        $location
        write-host LOADED ($location.kind) ($location.name)
    }
} 

function load-progress {
    $Global:depot = load-location $GLOBAL:depotName
    $Global:carrier = load-location "_carrier" 
    $Global:ship = load-location "_ship"
    write-host Loaded

    # EXTRA FOR THIS GUI - convert new data structure into original single-table version for display puposes
       $proghash = new-object hashtable
       $Global:depot.commodities |foreach {
                              $type = $_.type
                              $c = [Tprogressrow]::new()
                              $c.name = $_.name
                              $c.type = $_.type
                              [int64]($c.required) = [int64]($_.required) 
                              [int64]($c.Delivered) = [int64]($_.have)

                           

                              [int64]($c.ship) = $Global:ship.hash.$type.have
                              [int64]($c.carrier) = $Global:carrier.hash.$type.have
                              [int64]($c.remaining) = $c.required-$c.Delivered; 
                              $proghash.add($c.type,$c)
                              }
       $proghash
}


##############################################################################################
#   TABLE FORM
##############################################################################################
 class Ttable: Form {
 [button] $Bgo
 [button] $Brefresh
 [button] $Bstop
 [CheckBox] $CBFilter
 [CheckBox] $CBtobuy
 [combobox]$TBSystem 
 [label] $summary1
 [label] $summary2
 [label] $TrackerStatus
 [label] $Trackerlabel
 [textbox] $lastDepot
 [Listview] $LVtable 
 [hashtable] $goods
 [string] $lastSystem = ""
 [listbox] $depotchooser


[button]AddButton([System.EventHandler]$action,$text,$x,$y ){
     $Button = new-object button
     $Button.width = 50
     $Button.height = 40
     $Button.top = 0 +$y*($Button.height+10)
     $Button.left = 10 + $x*($Button.width+10) +$this.CBFilter.left +$this.CBFilter.width  
     $Button.text = $text
     $Button.add_click($action)
     $this.controls.add($Button)
     $needwidth = $Button.left + $Button.width + 20
     if ($this.width -lt $needwidth  ) {$this.width = $needwidth }
     return $button
}  
[button]AddButton([System.EventHandler]$action,$text,$x,$y,$hint ){
     $Button = $this.addButton($action,$text,$x,$y)
     $tt = [tooltip]::new()
     $tt.SetToolTip($Button, $hint)
     return $button
} 

addhint ([control]$ctl,$text) {
    $tt = [tooltip]::new()
    $tt.SetToolTip($ctl, $text)
}

 Ttable () {

 
 $Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",14

 $FontB = new-object system.drawing.font -ArgumentList $font,"Bold"
 $this.font = $FontB
 $this.width = 930
 $this.height = 800
 $this.text = "Colonisation Helper"
 $this.BackColor = "black"
 $this.foreColor = "white"
 $this.add_resize({ $this.LVTable.width = $this.width-30; $this.LVTable.height = $this.height- $this.LVTable.top -50;})  # $this.TBSystem.width = $this.width - 40

 $this.CBFilter = new-object CheckBox
 $this.CBFilter.width = 100
 $this.CBFilter.height = 20
 $this.CBFilter.top = 0
 $this.CBFilter.left = 10
 $this.CBFilter.text = "Deliver Only"
 $this.CBFilter.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",10
 $this.addhint($this.CBFilter, "Filter to see only commodities that are not complete")
 $this.controls.add($this.CBFilter)
 
 
 $this.CBtobuy = new-object CheckBox
 $this.CBtobuy.width = 100
 $this.CBtobuy.height = 20
 $this.CBtobuy.top =  $this.CBFilter.bottom
 $this.CBtobuy.left = 10
 $this.CBtobuy.text = "Buy Only"
 $this.CBtobuy.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",10
 $this.controls.add($this.CBtobuy)
 $this.CBtobuy.add_click({$this.parent.CBFilter.checked = $false;load_data })
 $this.cbFilter.add_click({$this.parent.CBtobuy.checked = $false;load_data })
$this.addhint($this.CBtobuy, "Filter to see only commodities that you still need to buy")
 $this.Bgo = $this.addbutton({display-griddata $editor; $editor.ShowDialog() },"Edit",0,0)
 $this.addhint($this.Bgo, "Edit carrier, ship or Active Depot numbers")

 
 # $this.Brefresh = $This.addbutton({ write-host "REFRESH BUTTON" },"Refresh List",1,0)
 
# $this.BStop = $This.addbutton({},"Quit",1,0)
# $this.BStop.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

 $this.Trackerlabel = new-object label
 $this.Trackerlabel.height = 20
 $this.Trackerlabel.top =  0
 $this.Trackerlabel.left =  $this.Bgo.width+ $this.Bgo.left +10
 $this.Trackerlabel.width = 75
 $this.Trackerlabel.text = "Tracker"
 $this.Trackerlabel.TextAlign = "topcenter"
 $this.Trackerlabel.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
 $this.addhint($this.Trackerlabel, "Tracker Status")
 $this.controls.add($this.Trackerlabel )

 $this.TrackerStatus = new-object label
 $this.TrackerStatus.height = 18
 $this.TrackerStatus.top =  $this.Trackerlabel.bottom
 $this.TrackerStatus.left =  $this.Trackerlabel.left
 $this.TrackerStatus.width = 75
 $this.TrackerStatus.text = "Tracker"
 $this.TrackerStatus.TextAlign = "topcenter"
 $this.TrackerStatus.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
 $this.addhint($this.TrackerStatus, "Tracker Status")
 $this.controls.add($this.TrackerStatus)

 $this.summary1 = new-object label
 $this.summary1.height = 25
 $this.summary1.top =  0
 $this.summary1.left =  $this.TrackerStatus.width+ $this.TrackerStatus.left +10
 $this.summary1.width = 300
 $this.summary1.text = "Comment"
 $this.summary1.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
  $this.addhint($this.summary1, "Overall delivery or buy progress")
 $this.controls.add($this.Summary1)

 $this.summary2 = new-object label
 $this.summary2.height = $this.summary1.height
 $this.summary2.top =  $this.summary1.bottom
 $this.summary2.left =  $this.summary1.left
 $this.summary2.width = $this.summary1.width
 $this.summary2.text = "Status - nothing to report"
 $this.summary2.Font = $this.summary1.Font 
 $this.addhint($this.summary2, "Current Journal File ID")
  $this.controls.add($this.Summary2)

$this.depotchooser = new-object listbox
$this.depotchooser.font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
$this.depotchooser.top =  $this.summary1.top
$this.depotchooser.left =  $this.summary1.right
$this.depotchooser.height =  $this.summary1.height
$this.depotchooser.width = 340
$this.depotchooser.add_SelectedIndexChanged({Change-Depot})
$this.addhint($this.depotchooser, "Active Depot Selector")
$this.controls.add($this.depotchooser)

$this.lastDepot = new-object textbox
$this.lastDepot.font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
$this.lastDepot.top =  $this.depotchooser.bottom
$this.lastDepot.left =  $this.depotchooser.left
#$this.lastDepot.height =  $this.summary2.height
$this.lastDepot.width = $this.depotchooser.width
$this.lastDepot.BackColor = "black"
$this.addhint($this.lastDepot, "Last Depot Docked. Double-click to copy name")
$this.lastDepot.add_doubleclick({$txt = $this.text.replace("?","");Set-Clipboard $txt})
$this.controls.add($this.lastDepot)


 $this.LVTable = new-object ListView
 $this.LVTable.font = $fontb
 $this.LVTable.width = $this.width-30; $this.LVTable.height = $this.height-230
 $this.LVTable.top =  $this.summary2.bottom+2
 $this.LVTable.height = $this.height- $this.LVTable.top -50
 $this.LVTable.left = 0
 $this.LVTable.gridlines = $true
 $this.LVTable.View  =  [System.Windows.Forms.View]::Details
 $this.LVtable.BackColor = "black"
 $this.controls.add($this.LVTable)
 $this.LVTable.Add_ItemActivate({CopyToClipboard})
  $this.LVTable.add_ColumnClick({SortListView $this $_.column})

   }

}

Function SortListView ([object]$LV,$Column) {
    Write-host ASK SORT $Column last was $GLOBAL:lastSortCol
    if ($column -eq $GLOBAL:lastSortCol) {$GLOBAL:sortOrder = !$GLOBAL:sortOrder } else {$GLOBAL:sortOrder =$true}
    $GLOBAL:lastSortCol = $column
 #   $LV.BeginUpdate()
    try {$Numeric = $true;$LV.items|foreach {[single]$X = $_.subitems[$Column].text} } catch {$Numeric = $false}
    if ($numeric) {
                $Newitems = $LV.items |sort -Property @{Expression={[single]$_.subitems[$Column].text};Ascending=$Global:sortOrder } |foreach { $_}
             } else {
                $Newitems = $LV.items |sort -Property @{Expression={$_.subitems[$Column].text};Ascending=$Global:sortOrder } |foreach { $_}
             }
    $LV.items.clear()
    $Newitems  |foreach {$item = $LV.items.add($_)}
  }


function load_data  {
    $instockTypes = [hashtable]::new()
    if ($marketData -ne $null) {$marketData.Items|where {$_.stock -gt 0}  |foreach {$M = $_.name -match '\$(.*)_name';$type = $matches[1];$instockTypes.add($type,$_.stock)}} #

    $table.LVTable.Clear()

    if ($table.CBFilter.Checked) {$Rows = $global:proghash.values |where {$_.required -gt $_.delivered}} else {$Rows = $global:proghash.values}
    if ($table.CBtobuy.Checked) {$Rows = $global:proghash.values |where {$_.required -gt ($_.delivered+$_.ship+$_.carrier)}}

    if ($rows -ne $null) {
         $cols = @("Name",'Stock',"Required","Delivered","Ship","Carrier","Remaining","Notes")
         $cols |foreach {$obj = $table.LVTable.columns.add($_,-2)}
        
             $Rows|sort name |foreach {
             $D = $_
             $type = $D.type
             if ($type -in $instockTypes.keys) {$stock = $instockTypes.$type} else {$stock = ""}
             $text = [string]($D.Name)
             $I = new-object Listviewitem($text)
           $obj = $I.Font = $fontB             
           $obj = $I.SubItems.add($stock) 
           $obj = $I.SubItems.add($D.required) 
           $obj = $I.SubItems.add($D.Delivered)  
           $obj = $I.SubItems.add($D.ship)       
           $obj = $I.SubItems.add($D.Carrier)                 
           $obj = $I.SubItems.add($D.Remaining) 
             $notes = ""
             $color = "White"
             $backColor = "Black"          

             [int64]$ship = $D.ship
             [int64]$carrier = $D.carrier
             [int64]$remaining = $D.remaining
             [int64]$buy = $D.required - $D.Delivered - $D.ship - $D.Carrier
             if (($buy) -gt 0) {$notes = "Buy $Buy"}
             if (($ship+$Carrier) -ge $Remaining) {$notes = "Enough bought";$color = "Orange"}
             if (($Carrier) -ge $Remaining) {$notes = "Enough On Carrier";$color = "Yellow"}
             if (($Ship) -eq $Remaining) {$notes = "Enough On Ship";$color = "lightBlue"}
             if (($Remaining) -le 0) {$notes = "Complete";$color = "lightGreen"}  
             if ($stock -gt 0) {$Backcolor = "darkBlue"}
             if ($ship -gt $remaining) {$notes = "Excess supply"; $color = "White";$Backcolor = "darkRed"}
             if ($D.required -eq 0) {$notes = "Extra"; $color = "magenta";$Backcolor = "black"}
           
              $I.ForeColor = $color
              $I.BackColor = $backColor
              $obj = $I.SubItems.add($notes)  

               $obj =$table.LVTable.items.add($I)

             }
        $table.LVtable.Columns|foreach {$_.width = 75}
        $table.LVtable.Columns[0].AutoResize(2);
        if ($marketData -ne $null) { $table.LVtable.Columns[1].AutoResize(2)} else {$table.LVtable.Columns[1].width = 0}
        $table.LVtable.Columns[$cols.count-1].AutoResize(2);
    } else {$table.LVTable.columns.add("Nothing to show",500,'center')} 

     if ($GLOBAL:lastSortCol -gt 0) {$resort = $GLOBAL:lastSortCol;$GLOBAL:lastSortCol = -1;SortListView $table.LVTable $resort}
     $all = $global:proghash.values 
     $allbuy = $all |where {($_.ship+$_.carrier) -lt $_.remaining}
     $TotDeliver = (sum $All.remaining)
     $TotBuy = (sum $Allbuy.remaining) - (sum $allbuy.ship) -(sum $allbuy.carrier)
     if ($cargoSize -gt 0) {
             $runsDeliver = "needing "+ [math]::Ceiling($totDeliver/$cargoSize) + " trips."
             $runsBuy = "needing "+ [math]::Ceiling($totBuy/$cargoSize) + " trips."
             } else {$runsDeliver=""; $runsBuy =""}
     if ($table.CBtobuy.Checked) {$table.summary1.text = "$totBuy to buy $runsBuy"} else
                                 {$table.summary1.text = "$totDeliver to deliver $runsDeliver"}
     }

$homedir = "C:\data\Scripts\Colonise\"
$progressfile = $homedir+"Progress.csv"
 $lastWrite = $null


function get-progress {

    $pf = Get-ChildItem ($progressdir+"*.json") |sort LastWriteTime |select -last 1
    $sf = get-item $statusfile
     if (test-path $marketfile) {$mf = get-item $marketfile} else {$mf = $null;$marketData = $null}

    if ($sf.LastWriteTime -ne $GLOBAL:lastStatus) {
        $StatusJson = Get-Content $statusfile
        $status = ConvertFrom-Json "$StatusJson"
        $table.summary2.text = $status.comment.replace("Journal.","").replace(".log","")
        $GLOBAL:TrackerPID = $status.processID
        $GLOBAL:cargosize = $status.CargoCapacity
        $GLOBAL:StarSystem = $status.StarSystem
        $table.lastDepot.text = $status.lastDepot
        if ($status.lastDepot[0] -ne '?') {$table.lastDepot.ForeColor = "lightGreen"} else {$table.lastDepot.ForeColor ="Pink"}
       # $newdepotname = $status.activeDepot
       # if ($newdepotname -ne $GLOBAL:depotname) {$GLOBAL:lastWrite = $null }  # force reload if changing depot
       # $GLOBAL:depotname = $newdepotname
      $GLOBAL:lastStatus = $sf.LastWriteTime 

    }

    if ($mf.LastWriteTime -ne $GLOBAL:lastMarket) {
       if ($mf -ne $null) {$MarketJson = Get-Content $Marketfile
                            $GLOBAL:marketData = ConvertFrom-Json "$MarketJson"
                            } else {$GLOBAL:marketData = $null}
        load_data $progHash
        $GLOBAL:lastMarket = $mf.LastWriteTime 
    }
    
    if ($pf.LastWriteTime -ne $GLOBAL:lastWrite) {
      # clear
        write-host ($pf.LastWriteTime)
       
      
       $GLOBAL:proghash = load-progress
       $progress = $GLOBAL:proghash.values |sort name
       $progress
       $totdel = sum $progress.delivered
       $totreq = sum $progress.required
       $pc = [math]::round($totdel/$totreq*100,1)
    #   write-host total: $totreq delivered: $totdel $pc%
        $GLOBAL:lastWrite = $pf.LastWriteTime 
       load_data $progHash
       }

     $trackerProcess = get-process -id $GLOBAL:TrackerPID -ErrorAction SilentlyContinue
     if ($trackerProcess.name -match "powershell") {$tracktext = "OK";$trackcolor = "lightGreen"} else {$tracktext = "OFF";$trackColor="Pink"}
       $table.TrackerStatus.text = $tracktext
       $table.TrackerStatus.ForeColor = $trackcolor
       
      
}
######################################################################################################
#   EDITOR GRIDVIEW
######################################################################################################

function display-griddata ($editor){
     $editor.grid.rows.Clear()
      $GLOBAL:proghash.values|sort name| foreach  {
      $r=  $editor.grid.rows.add(($_.name,$_.type,$_.Required,$_.Delivered,$_.ship,$_.Carrier,$_.remaining))
   $r= $editor.grid.rows |foreach {
                    $bc = "black"
                    $fc = "white"
                    if ($_.cells[6].value -eq 0) { $fc = "green"}
                    if (($_.cells[5].value+$_.cells[4].value) -gt $_.cells[6].value) { $fc = "yellow"}
                    $_.DefaultCellStyle.backcolor = $bc
                    $_.DefaultCellStyle.ForeColor = $fc
                    }
    }

}

function save-griddata {
        Write-host SAVE DATA 
        $editor.grid.rows | where {$_.cells[1].value -ne $null} | Foreach  {
                $row = $_
                $type = $row.cells[1].value
             #   write-host Get data for $type
                [int64]$req = $row.cells[2].value
                [int64]$del = $row.cells[3].value
                [int64]$shi = $row.cells[4].value
                [int64]$car = $row.cells[5].value
                [int64]$rem = $row.cells[6].value

                $GLOBAL:proghash.$type.Required = $req
                $GLOBAL:Depot.hash.$type.required = $req

                $GLOBAL:proghash.$type.Delivered = $del
                $GLOBAL:Depot.hash.$type.have = $del

                $GLOBAL:proghash.$type.ship = $shi
                $GLOBAL:Ship.hash.$type.have = $shi

                $GLOBAL:proghash.$type.carrier= $car
                $GLOBAL:carrier.hash.$type.have = $car

                $GLOBAL:proghash.$type.Remaining = $rem
                }

            save-progress


        }

function load-carrier {
    $rawlines = get-clipboard
            #trim pre-table lines
            $TSV = [System.Collections.Generic.List[string]]::new()
            $rawlines |foreach {if ($_ -match "^.*Cr.*CR$|^Commodities	Value	Qty	Total") {$tsv.ADD($_)} }
            if ($TSV.Count -gt 0) {
                $TSV[0] = $TSV[0].replace("Commodities","Name")
              #  $TSV =$TSV.replace(",","").replace(" ","").ToLower()

                $cargoArray = $TSV |convertFrom-csv -Delimiter "`t" |select Name,Qty
                $cargo = [hashtable]::New()
                $cargoArray |foreach {$cargo.add($_.name.tolower(),$_.qty)}
                foreach ($row in $editor.grid.rows) {
                        $t = $row.cells[0].value
                        if ($t -ne $null) {$t = $t.tolower()
                            if ($t -in $cargo.keys) {$row.cells[5].value= $cargo.$t} else {$row.cells[5].value=0}
                            }
                }
            }
}


function cell-change ($s,$c,$r){
[int64]$value = $s.rows[$r].cells[$c].value
if ($c -in (2,3)) {$remain = $s.rows[$r].cells[2].value - $s.rows[$r].cells[3].value ; $s.rows[$r].cells[6].value = $remain}
if ($c -in (7)) { $s.rows[$r].cells[3].value = $s.rows[$r].cells[3].value + $value; $s.rows[$r].cells[7].value = ""}
if ($c -in (6)) {$Delivered = $s.rows[$r].cells[2].value - $s.rows[$r].cells[6].value ; $s.rows[$r].cells[3].value = $delivered}
} 

function cell-validating ($s,$e){
    $c = $e.columnindex
    $r = $e.rowindex
 <#   if ($c -in (0,1)) {$ret = $false} ELSE {
        try {   $string =  $s.rows[$r].cells[$c].value
                [int64]$value = $string
                if ($c -in (2..6)) {$ret = !($value -in (0..10000000))}
                if ($c -in (7)) {$ret = !($value -in (-1000..1000))}
            } catch {$ret= $true}
         }
    $ret
    write-host $ret #>
}
 
class Tgrid: Form {

[datagridview]$Grid

[button]AddButton([System.EventHandler]$action,$text,$x,$y ){
     $Button = new-object button
     $Button.width = 150
     $Button.height = 40
     $Button.top = 5 +$y*($Button.height+10)
     $Button.left = 10 + $x*($Button.width+10) +$this.CBFilter.left +$this.CBFilter.width  
     $Button.text = $text
     $Button.add_click($action)
     $this.controls.add($Button)
     $needwidth = $Button.left + $Button.width + 20
     if ($this.width -lt $needwidth  ) {$this.width = $needwidth }
     return $button
}  
[button]AddButton([System.EventHandler]$action,$text,$x,$y,$hint ){
     $Button = $this.addButton($action,$text,$x,$y)
     $tt = [tooltip]::new()
     $tt.SetToolTip($Button, $hint)
     return $button
} 
Doresize ($o) {
     $o.width = $this.width -50
     $o.height = $this.height -$this.grid.top-60
}

Tgrid () {


 
 $Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",14

 $FontB = new-object system.drawing.font -ArgumentList $font,"Bold"
 $this.font = $Font
 $this.width = 900
 $this.height = 800

 $This.addbutton({display-griddata $this.parent},"Reload",0,0)
 $This.addbutton({save-griddata},"Save",1,0)
 $This.addbutton({load-carrier},"Paste Carrier",2,0,"Clipboard must contain copy of Inara Carrier cargo page")

 $this.text = "Colonisation Progress File Editor"

 $this.grid = [datagridview]::new() 
 $this.grid.top = 60
 $this.grid.width = $this.width -50
 $this.grid.height = $this.height -$this.grid.top-60
 $headings = ("Name","Type","Required","Delivered","Ship","Carrier","Remaining","(+/-)")
 $this.grid.ColumnCount = $headings.count
  (0..($headings.count-1)) |foreach {$this.grid.Columns[$_].name = $headings[$_]}

  $this.grid.Add_CellValueChanged({ param ($s,$e); 
                                    Cell-change $s $e.columnindex $e.rowindex})
  $this.grid.Add_CellValidating({ param ($s,$e); 
                                   $e.cancel = (Cell-validating $s $e)})

 $this.controls.add($this.grid)

 $this.grid.ColumnHeadersHeight = 40
 $this.grid.Columns[0].width = 300
 $this.grid.Columns[1].width = 0
 $this.grid.Columns[4].width = 70
 $this.grid.Columns[5].width = 70
 $this.grid.Columns[0].readonly = $true
 $this.grid.Columns[1].readonly = $true
 $this.add_resize({$this.DoResize( $this.grid)})

 Display-griddata $this

 }
 }

 $editor= new-object TGrid
 #$editor.ShowDialog()


$table= new-object Ttable 
$depotfiles = Get-ChildItem ($progressDir+"*.json") |where {$_.name -notlike "_*"} |sort name
$table.depotchooser.items.clear()
$depotnames = $depotfiles.name |foreach {$table.depotchooser.items.add($_.replace(".json",""))}
$Statusjson = get-content $statusFile
$status = convertfrom-json "$StatusJson"
$Index = $table.depotchooser.items.IndexOf($status.ActiveDepot)
if ($index -lt 0) {$index = 0}
$table.depotchooser.SelectedIndex = $Index

$GLOBAL:depotName = $status.ActiveDepot
$global:proghash = load-progress
load_data

$timer = New-Object System.Windows.Forms.Timer
$timer.stop()
  $timer.Interval = 1000
  $timer.add_tick({get-progress; })
$timer.Start()
$Button = $table.Showdialog()  
$timer.stop()
  