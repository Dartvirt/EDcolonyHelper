﻿######################################################################################################
# ColoniseMakeTemplates
# Part of Dart's colonisation script set
# create a new progress.csv for use with colony helper tools
# creates file from a database of know facility requiements
# will accept multiple or repeats of the facilities to create a merged file for a multi facility build
#
# From the presented menu, enter the number(s) of the facilities comma seperate
# if carrier.txt is present, assumes this is a copy-paste from inara of the carrier cargo table.
# carrier data is added to the progress.csv carrier column
#
# Version 2.1
######################################################################################################
using namespace System.Windows.Forms
add-type -AssemblyName  System.Windows.Forms

$host.ui.RawUI.WindowTitle = 'Colonisation Templates Console'
$scriptpath =$MyInvocation.MyCommand.Path
if ($scriptpath -eq $null) {$homedir = "C:\data\Scripts\Colonise\"} else {$homedir = (split-path $scriptpath )+ "\"}
$templateDir = "$homedir\templates\"

#$csv = Get-Content .\ColonizationCommodities.csv
$carrierfile = $templateDir+"carrier.txt"
$progressDir = $HomeDir+"progress\" 
$CarrierTemplate = $templateDir+"_carrier.json" 
$databaseFile = $templateDir+"databaseV2.json" 
$carrierRego = "H0N-B2L"
$header = (0..70)|foreach {[string]$_}
#$shoplist = $csv |ConvertFrom-Csv -Header $header

class Tcommodity {
[string]$Name
[string]$Type
[INT64]$Required
[INT64]$Have
}

class Tfacility {
[string]$ID
[string]$category
[string]$Build
[string]$variant
[Tcommodity[]]$commodities
}

Class Tlocation {
[string]$name
[string]$kind
[string]$comment
[string]$Registration
[Tcommodity[]]$commodities
}

# load carrier data to carrier progress file
function load-carrier {
    $rawlines = get-clipboard
            #trim pre-table lines
            $TSV = [System.Collections.Generic.List[string]]::new()
            $rawlines |foreach {if ($_ -match "^.*Cr.*CR$|^Commodities	Value	Qty	Total") {$tsv.ADD($_)} }
            if ($TSV.Count -gt 0) {
                $TSV[0] = $TSV[0].replace("Commodities","Name")
              #  $TSV =$TSV.replace(",","").replace(" ","").ToLower()

                $cargoArray = $TSV |convertFrom-csv -Delimiter "`t" |select Name,Qty
                $cargo = [hashtable]::New()
                $cargoArray |foreach {$cargo.add($_.name.tolower(),$_.qty)}
                $carrierJson = get-content $CarrierTemplate
                $carrier = convertfrom-json "$carrierJson"
                $carrier.comment = "Fleet Carrier"
                $carrier.registration = $carrierRego
                foreach ($row in $carrier.commodities) {
                        $t = $row.Name
                        if ($t -ne $null) {$t = $t.tolower()
                            if ($t -in $cargo.keys) {$row.Have= $cargo.$t} else {$row.Have= 0} 
                            }
                }
              $carrierJson = $carrier |convertTo-json
              $carrierJson |Set-Content ($ProgressDir+"_carrier.json") -Force
              [messagebox]::show("Carrier file updated to match inara")
            } else {[messagebox]::show("No Carrier data in Clipboard, Carrier file not changed")}
            #if ($TSV.Count -gt 0)
}


function load-griddata ($Index) {
    $GLOBAL:entry = $database[$Index]
    $progress = $database[$Index].commodities
           $GLOBAL:proghash = new-object hashtable
           $progress |foreach {  [int64]($_.required) = [int64]($_.required) 
                              [int64]($_.Have) = [int64]($_.delivered)
                              $GLOBAL:proghash.add($_.type,$_)
                              }
         }

function save-change ($Index) {
write-host "updating $Index"
    $global:database[$index].commodities.clear()
    $newvals = @()
    $editor.grid.rows|where {$_.cells[0].value -ne $null} |foreach {$nc = [Tcommodity]::new()

                            [int64]$req = $_.cells[2].value
                            [int64]$hav = $_.cells[3].value

                            $nc.name = $_.cells[0].value
                            $nc.Type = $_.cells[1].value
                            $nc.Required = $req
                            $nc.Have = $hav
                            $newvals = $newvals +$nc}
    $global:database[$index].commodities.clear()
    $global:database[$index].commodities = $newvals

    $jsons = $global:database |foreach { $_ |convertTo-json -Compress }
    $jsons | set-Content $databaseFile 

}

function display-griddata ($editor){
     $editor.grid.rows.Clear()
      $GLOBAL:proghash.values|sort name| foreach  {
      $r=  $editor.grid.rows.add(($_.name,$_.type,$_.Required,$_.Have))
   $r= $editor.grid.rows |foreach {$_.height = 25}
    }

}

function export-griddata {
        Write-host SAVE DATA 
        
        $editor.grid.rows | where {$_.cells[1].value -ne $null} | Foreach  {
                $row = $_
                $type = $row.cells[1].value
             #   write-host Get data for $type
                [int64]$req = $row.cells[2].value
                [int64]$hav = $row.cells[3].value

                $proghash.$type.Required = $req
                $proghash.$type.have = $hav

                }
         $values = $proghash.VALUES  |sort name
         $Location = [Tlocation]::new()
         $location.kind = "Depot"
         $Location.comment = ($entry.location,$entry.category,$entry.type,$entry.variant) -join ","
         $location.name = $editor.TBstation.text
         $location.commodities = $values
         $progressJSON = $location |convertto-json
       #  $header = "#"+$editor.chooser.Selecteditem
       #  $progressCSV[0] = $header
        $progressfileName = $progressDIR+$editor.TBstation.text+".json"
         $ask=[System.Windows.Forms.DialogResult]::Yes
         if (test-path $progressfileName) {$ask = [messagebox]::show("File exists.  Over-write file?","WARNING",'yesno')}
         if ($ask -eq [System.Windows.Forms.DialogResult]::Yes) {
                        $progressJSON |out-file $progressfileName -force;
                        $editor.TBstation.text = ""
                        
                        }
        }

function cell-change ($s,$c,$r){
[int64]$value = $s.rows[$r].cells[$c].value

} 

function cell-validating ($s,$e){
    $c = $e.columnindex
    $r = $e.rowindex
 <#   if ($c -in (0,1)) {$ret = $false} ELSE {
        try {   $string =  $s.rows[$r].cells[$c].value
                [int64]$value = $string
                if ($c -in (2..6)) {$ret = !($value -in (0..10000000))}
                if ($c -in (7)) {$ret = !($value -in (-1000..1000))}
            } catch {$ret= $true}
         }
    $ret
    write-host $ret #>
}

Function add-row  {
   $newList = $ConstructionCommodities.commodities |where {$_.name -notin $GLOBAL:proghash.Values.name}
   $FormCS.Load($newlist.name)
   if ($FormCS.showdialog() -eq [dialogresult]::Ok)  {
        $FormCS.LBcommodities.SelectedIndices |foreach {
            $i = $_
            $newRow = [Tcommodity]::new()
            $newrow.name = $newList[$i].name
            $newrow.type = $newList[$i].type
            Write-host $i ($newRow.name) ($newrow.Type)
            $GLOBAL:proghash.add($newrow.type,$newrow)
            }
        display-griddata $editor
   } 
}

Function Delete-row  {
    $editor.grid.SelectedRows |foreach  {
    $type = $editor.grid.SelectedRows.cells[1].Value
    $global:proghash.remove($type)
    }
 display-griddata $editor
}

class Commodity_selector : Form {

 [button] $Bok
 [button] $Bcancel
 [listBox] $LBcommodities

  
 load ([System.Collections.ArrayList]$list) {
    $this.LBcommodities.Items.clear()
    $list|foreach  {$X = $this.LBcommodities.Items.Add($_) }
   # $this.LBcommodities.SelectedIndex = 0
    
 }


 Commodity_selector () {
 $this.width = 650
 $this.height = 800
 $this.text = "Select mineral"

 $buttonstart = $this.height -120
 $font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
 
 $this.LBcommodities = new-object ListBox
 $this.LBcommodities.width = $this.width-40
 $this.LBcommodities.height = $this.height -150
 $this.LBcommodities.top = 30
 $this.LBcommodities.left = 10
 $this.LBcommodities.Font = new-object system.drawing.font -ArgumentList "Courier New",12
 $this.LBcommodities.enabled = $true
 $this.LBcommodities.SelectionMode = "Multisimple"
 $this.controls.add($this.LBcommodities)


 $this.Bcancel = new-object button
 $this.Bcancel.width = 100
 $this.Bcancel.height = 40
 $this.Bcancel.top =  $buttonstart
 $this.Bcancel.left = 10
 $this.Bcancel.text = "Cancel"
 $this.Bcancel.Font = $this.LBminables.Font 
 $this.Bcancel.Dialogresult =[dialogresult]::Cancel
 $this.controls.add($this.Bcancel)

 $this.Bok = new-object button
 $this.Bok.width = 100
 $this.Bok.height = 40
 $this.Bok.top =  $buttonstart
 $this.Bok.left = 100
 $this.Bok.text = "Add"
 $this.Bok.Font = $this.LBminables.Font 
 $this.Bok.Dialogresult =[dialogresult]::Ok
 $this.controls.add($this.Bok)


 $this.cancelButton = $this.Bcancel
 $this.AcceptButton = $this.accept
 
 }
}
 

class Tgrid: Form {

[datagridview]$Grid
[listbox]$chooser
[textbox]$TBstation
[Button]$BNexport
[Button]$BNAddrow 

[button]AddButton([System.EventHandler]$action,$text,$x,$y ){
     $Button = new-object button
     $Button.width = 100
     $Button.height = 40
     $Button.top = 5 +$y*($Button.height+10)
     $Button.left = 10 + $x*($Button.width+10) +$this.CBFilter.left +$this.CBFilter.width  
     $Button.text = $text
     $Button.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",10,([System.Drawing.FontStyle]"bold")
     $Button.add_click($action)
     $this.controls.add($Button)
     $needwidth = $Button.left + $Button.width + 20
     if ($this.width -lt $needwidth  ) {$this.width = $needwidth }
     return $button
}  

[button]AddButton([System.EventHandler]$action,$text,$x,$y,$hint ){
     $Button = $this.addButton($action,$text,$x,$y)
     $tt = [tooltip]::new()
     $tt.SetToolTip($Button, $hint)
     return $button
} 

Doresize ($o) {
     $o.width = $this.width -50
     $o.height = $this.height -$this.grid.top-60
}

Tgrid () {


 
 $Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12

 $FontB = new-object system.drawing.font -ArgumentList $font,"Bold"
 $this.font = $Font
 $this.width = 1200
 $this.height = 1200

 $Bn =$This.addbutton({load-griddata $this.parent.chooser.SelectedIndex;display-griddata $this.parent},"Reload",0,0,"Reload losing any changes")
 $Bn =$This.addbutton({save-change $this.parent.chooser.SelectedIndex},"Save Change",1,0, "Save changes to database")
 $Bn =$This.addbutton({load-carrier},"Update Carrier",2,0,"Clipboard must contain copy of Inara Carrier cargo page")
 #$Bn.enabled =(test-path $global:carrierfile)
 $this.BnExport =$This.addbutton({export-griddata},"Export",3,0,"Export to Progress file")
 $this.BnExport.enabled = $False
 $this.BnAddrow =$This.addbutton({Add-Row},"Add row",0,1,"Add more commodities to this template")
 $Bn =$This.addbutton({Delete-Row},"Delete row",1,1,"Delete selected commodities from this template")
 $this.TBStation = [textbox]::new()
 $this.TBStation.left = $this.BnExport.right+5
 $this.TBStation.top = $this.BnExport.top
 $this.TBStation.width = 500
 $this.TBStation.add_TextChanged({$this.parent.BNExport.enabled = $this.text -gt ""})
 $this.controls.add($this.TBStation)


 $this.text = "Colonisation Templates Editor"
 $this.chooser = [listbox]::new()
 $this.chooser.top = $This.BnAddrow.bottom +5
 $this.chooser.height =150
 $this.chooser.width = $this.width -50
 $this.controls.add($this.chooser)
 $global:database |foreach {$txt = "{0,2}:{1,-30} {2,-30} {3,-30} {4,-100}" -f $_.ID,$_.Location.trim(),$_.Category.trim(),$_.Type.trim(),$_.variant.trim()
                            $this.chooser.items.add($txt)}
$this.chooser.add_click({load-griddata $this.SelectedIndex;Display-griddata $this.parent})
 $this.grid = [datagridview]::new() 
 $this.grid.top = $this.chooser.top +$this.chooser.height + 5
 $this.grid.width = $this.width -50
 $this.grid.height = $this.height -$this.grid.top-60
 $headings = ("Name","Type","Required","Have")
 $this.grid.ColumnCount = $headings.count
  (0..($headings.count-1)) |foreach {$this.grid.Columns[$_].name = $headings[$_]}

  $this.grid.Add_CellValueChanged({ param ($s,$e); 
                                    Cell-change $s $e.columnindex $e.rowindex})
  $this.grid.Add_CellValidating({ param ($s,$e); 
                                   $e.cancel = (Cell-validating $s $e)})

 $this.controls.add($this.grid)

 $this.grid.ColumnHeadersHeight = 30
 $this.grid.ColumnHeadersDefaultCellStyle.font = $FontB 
 $this.grid.Columns[0].width = 350
 $this.grid.Columns[1].width = 10
 $this.grid.Columns[0].readonly = $true
 $this.grid.Columns[1].readonly = $true
 $this.add_resize({$this.DoResize( $this.grid)})

 # load-griddata;Display-griddata $this

 }
 }


function make-ConstructionCommodities {  
        # Makes a set of commodities containing every commodity found in the database.
        # Only used once, should not be needed again

    $Everything = [Tlocation]::new()
    $database | foreach {
        $_.commodities |where {$_.name -notin $everything.commodities.name} |foreach {
            $cmdty = [Tcommodity]::new()
            $cmdty.name = $_.name
            $cmdty.type = $_.type
            $everything.commodities = $everything.commodities + $cmdty
            }
    }
    $everything.commodities = $everything.commodities |sort name
    $Everything.name = "_ConstructionCommodities"
    $Everything.kind = "reference"
    $Everything.comment = "All Construction Commodities"
    $Everything |convertTo-json |out-file ($templateDir+"_ConstructionCommodities.json")
}


$jsons = Get-Content $databaseFile
$database = $jsons |foreach  {convertfrom-Json $_ }
if (!(test-path ($templateDir+"_ConstructionCommodities.json"))) {make-ConstructionCommodities}
$json = get-content ($templateDir+"_ConstructionCommodities.json")
$ConstructionCommodities = convertfrom-json "$json"
$keysdata = $database |foreach {$_.commodities}|select name,Type -Unique|sort name
$keyslookup = [hashtable]::new()
$keysdata |foreach {$keyslookup.add($_.name,$_.type)}


$FormCS = [Commodity_selector]::new()
 $editor= new-object TGrid
 $editor.ShowDialog()