﻿######################################################################################################
# ColoniseMonitorGUI
# Part of Dart's colonisation script set
# Monitors and displays commodity movements recorded in progress files for ED colonisation purposes
# With Edit function
######################################################################################################
using namespace System.Windows.Forms
using namespace System.drawing
add-type -AssemblyName  System.Windows.Forms

$host.ui.RawUI.WindowTitle = 'Colonisation Monitor Console'
$scriptpath =$MyInvocation.MyCommand.Path
if ($scriptpath -eq $null) {$homedir = "C:\data\Scripts\Colonise\"} else {$homedir = (split-path $scriptpath )+ "\"}
$templateDir = "$homedir\templates\"
$progressfile = $homedir+"Progress.csvBAD"   # not using, but dont want to trash old one by accident
$progressfileNew = $homedir+"Progress.csvBAD"
$DefaultcargoSize = 700
$LargePadCargosize = 400  # Used only if ship pad size is not known. Inara buy search will be set to large pad if cargo capacity above this value, otherwise medium or larger
$GLOBAL:cargoSize = $DefaultcargoSize
$progressDir = $homedir+"Progress\" 
$carrierfile = $progressDir+"_carrier.json"
$shipfile = $progressDir+"_ship.json"
$GLOBAL:depotName = $null
$statusfile = $homedir+"statusV2.json"
$SettingsFile = $homedir+"SettingsV2.json"
$marketfile = $homedir+"market.json"
$defaultColumnWidth = 80
 $lastWrite = $null
 $lastStatus = $null
 $lastMarket = $null

$marketData= $null

$inaraTEMPLATE = "https://inara.cz/elite/commodities/?formbrief=1&pi10=3&pi11=0&pi9=0&pi4=0&pi14=0&pi5=720&pi12=0&pi7=0&pi8=0&pi13=1"

$lookupID = get-content C:\data\Scripts\Colonise\InaraCommodities.csv |convertFrom-csv

class TprogressRow {
[string]$name
[string]$type
[int64]$ship
[int64]$Required
[int64]$Delivered
[int64]$Carrier
[int64]$Remaining

}
class Tcommodity {
[string]$Name
[string]$Type
[INT64]$Required
[INT64]$Have
}

Class Tlocation {
[string]$name
[string]$starSystem
[string]$kind
[string]$comment
[string]$Registration
[Tcommodity[]]$commodities = @()
}

Class Tsettings {
[string]$activeDepot
}

function search-inara ($action,$commodity,$pad,$System) {

    $action = "&pi1=$action"
    $system = "&ps1=$system"
    $pad = "&pi3=$pad"

    if ($system -ne $null) {$ID = ($lookupID |where {$_.commodity -ieq $Commodity}).id;$ID = "&pa1[]=$ID" } else {$ID = ""}

    $url = $inaraTEMPLATE + $action + $ID + $system + $pad
    Start-Process $URL

}
function change-depot {
  if (test-path $settingsFile) {
          $json = get-content $settingsFile
          $settings = convertfrom-json "$Json"
          } else {$settings = [Tsettings]::new() }
  $newDepot= $table.depotchooser.SelectedItem 

  if ($newdepot -ine  $settings.activeDepot) {
     $settings.activeDepot = $newDepot
     $GLOBAL:depotName = $newDepot
     $GLOBAL:proghash = load-progress
     load_data 
      Write-host CHANGE DEPOT TO ($settings.activeDepot)
      $json = $Settings | ConvertTo-json
      $json | set-content $settingsFile -force
      }
      $table.depotSystem.Text = $GLOBAL:depot.starsystem
}

function copyToClipboard {

$text = $table.LVtable.SelectedItems[0].Text
write-host copy to cipboard and lookup:  $text
Set-Clipboard $text
$table.LVtable.SelectedItems.Clear()  # this stops the row being blanked out
$pad = "SML".IndexOf($Global:padsize)+1
if ($pad -eq 0) {if ($cargosize -gt $LargePadCargosize) {$pad = 3} else {$pad = 2}}  # default to cargo size method if the actual pad size is not known
#
search-inara 1 $text $pad $GLOBAL:StarSystem
}


function sum($a) {
    $S= 0
    $a |foreach {$S = $S + $_}
    $s
    }

class TStatus {
[string]$heartbeat
[string]$comment
}

function remove-hash ($loc) {
    $values = $loc.hash.values
    $loc.commodities = $values |sort type
    $loc |select name,starsystem,kind,comment,registration,commodities
}

function save-location ($location) {
    $loc = remove-hash $location
    $json = $loc|convertTo-json
    $fname = $progressDir + $location.name + ".json"
    $json |out-file $fname
}

function save-progress {
    save-location $Global:depot
    save-location $Global:carrier
    save-location $Global:ship
}

function add-hash ($loc) {
    $hash = [hashtable]::new()
    $loc.commodities |foreach {$hash.add($_.type,$_)}
    $loc |add-member -MemberType NoteProperty -Name hash -value $hash
    $loc.commodities = @() # we only use the hash now.  it will be put back if/when saved.
    $loc
}

function load-locationOne ($Dname) {
    $fname =  $progressDir+$Dname+".json" 
   if (($Dname -ne $null) -and (test-path $fname)) {
        $fname =  $progressDir+$Dname+".json"   #$carrierfile =
        $json = get-content $fname 
        $location = convertfrom-json "$json"
        $location = add-hash $location
        $location.name = $Dname
        $location
     #   write-host LOADED ($location.kind) ($location.name)
    } else {$null}
} 

function merge-depot ($All,$next) {

  if ($All -eq $null) {$next} else
        {$next.hash.values |foreach {
            $type = $_.type
            $name = $_.name
            $req = $_.required
            $hav = $_.have
            if ($type -in $ALL.hash.keys) { 
     #          write-host ADDED $type $name
                $ALL.hash.$type.required = $ALL.hash.$type.required + $req
                $ALL.hash.$type.have = $ALL.hash.$type.have + $hav
                   } Else {$ALL.hash.add($type,$_)}
            }
         $All

        }

}

function get-DepotStarsystems {
      $StarSystems = @() # Initialise list to hold all StarSystems

      $GLOBAL:Depotnames |foreach {
          $nextDepot = load-locationOne $_
          $StarSystems = $StarSystems + $nextDepot.StarSystem
          }
        $StarSystems|select -Unique |where {$_ -gt ""} |sort
}

function load-location ($Dname) {
   if ($Dname -notmatch "\*.*\*") {$table.Bgo.Enabled = $true;load-locationOne $Dname} else
      {  # Must be a group or *ALL*
      $EveryDepot = @() # Initialise list to hold all depots
      $table.Bgo.Enabled = $false  # No edit in group mode

      $GLOBAL:Depotnames |foreach {
          $nextDepot = load-locationOne $_
          $EveryDepot = $EveryDepot + $nextDepot
          }
      $Groupdepot =  add-hash ([Tlocation]::new())
      $filter = ".*"
      if ($Dname -ne "*ALL*") {$filter = $Dname.replace("*","")}
       $everyDepot|where {$_.Starsystem -match $filter} |foreach {
          $Groupdepot = merge-depot $Groupdepot $_
          }
      $Groupdepot.name = "_GROUP"
      $Groupdepot.Kind = "_GROUP"
      $Groupdepot.comment = "Group of depots"
      $Groupdepot.registration = ""
      $Groupdepot
      }
} 

function load-progress {
    $Global:depot = load-location $GLOBAL:depotName
    $Global:carrier = load-location "_carrier" 
    $Global:ship = load-location "_ship"
    write-host Loaded

    # EXTRA FOR THIS GUI - convert new data structure into original single-table version for display puposes
       $proghash = new-object hashtable
       $Global:depot.hash.values |foreach {
                              $type = $_.type
                              $c = [Tprogressrow]::new()
                              $c.name = $_.name
                              $c.type = $_.type
                              [int64]($c.required) = [int64]($_.required) 
                              [int64]($c.Delivered) = [int64]($_.have)
                              [int64]($c.ship) = $Global:ship.hash.$type.have
                              [int64]($c.carrier) = $Global:carrier.hash.$type.have
                              [int64]($c.remaining) = $c.required-$c.Delivered; 
                              # write-host ADDING ($c.name)
                              $proghash.add($c.type,$c)
                              }
       $proghash
}

function delete-depot {
    $index = $table.depotchooser.SelectedIndex
    $text = $table.depotchooser.SelectedItem
    if ($text -ine "*ALL*") {
        if ([messagebox]::Show("Archive depot $text ?","Warning","Yesno") -eq "Yes") {
             $table.depotchooser.SelectedIndex = 0
             $Global:depotname = $table.depotchooser.SelectedItem
             $global:settings.activeDepot = $Global:depotname
             $table.depotchooser.items.Remove($text)
             $fname = $progressDir + $text + ".json"
             mv $fname ($fname+".archive") -force
             write-host Archived $text
                }
        }
}

##############################################################################################
#   TABLE FORM
##############################################################################################
 class Ttable: Form {
 [button] $Bgo
 [button] $Bdelete

 [CheckBox] $CBFilter
 [CheckBox] $CBtobuy
 [CheckBox] $CBStock
 [combobox]$TBSystem 
 [label] $summary1
 [label] $summary2
 [label] $TrackerStatus
 [label] $Trackerlabel
 # [textbox] $lastDepot
 [Listview] $LVtable 
 [hashtable] $goods
 [string] $lastSystem = ""
 [combobox] $depotchooser
 [label] $depotSystem


[button]AddButton([System.EventHandler]$action,$text,$x,$y ){
     $Button = new-object button
     $Button.width = 50
     $Button.height = 40
     $Button.top = 0 +$y*($Button.height+10)
     $Button.left = 10 + $x*($Button.width+10) +$this.CBFilter.left +$this.CBFilter.width  
     $Button.text = $text
     $Button.add_click($action)
     $this.controls.add($Button)
     $needwidth = $Button.left + $Button.width + 20
     if ($this.width -lt $needwidth  ) {$this.width = $needwidth }
     return $button
}  
[button]AddButton([System.EventHandler]$action,$text,$x,$y,$hint ){
     $Button = $this.addButton($action,$text,$x,$y)
     $tt = [tooltip]::new()
     $tt.SetToolTip($Button, $hint)
     return $button
} 

addhint ([control]$ctl,$text) {
    $tt = [tooltip]::new()
    $tt.SetToolTip($ctl, $text)
}

 Ttable () {

 
 $Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12

 $FontB = new-object system.drawing.font -ArgumentList $font,"Bold"
 $this.font = $FontB
 $this.width = 1200
 $this.height = 800
 $this.text = "Colonisation Monitor"
 $this.BackColor = "black"
 $this.foreColor = "white"
 $this.add_resize({ $this.LVTable.width = $this.width-30; $this.LVTable.height = $this.height- $this.LVTable.top -50;})  # $this.TBSystem.width = $this.width - 40

 $this.CBFilter = new-object CheckBox
 $this.CBFilter.width = 110
 $this.CBFilter.height = 20
 $this.CBFilter.top = 0
 $this.CBFilter.left = 10
 $this.CBFilter.text = "Deliver Only"
 $this.CBFilter.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",10
 $this.addhint($this.CBFilter, "Filter to see only commodities that are not complete")
 $this.controls.add($this.CBFilter)
 
 
 $this.CBtobuy = new-object CheckBox
 $this.CBtobuy.width = 110
 $this.CBtobuy.height = 20
 $this.CBtobuy.top =  $this.CBFilter.bottom
 $this.CBtobuy.left = 10
 $this.CBtobuy.text = "Buy Only"
 $this.CBtobuy.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",10
 $this.controls.add($this.CBtobuy)
 $this.CBtobuy.add_click({$this.parent.CBFilter.checked = $false;load_data })
 $this.cbFilter.add_click({$this.parent.CBtobuy.checked = $false;load_data })
$this.addhint($this.CBtobuy, "Filter to see only commodities that you still need to buy")

 $this.CBStock = new-object CheckBox
 $this.CBStock.width = 110
 $this.CBStock.height = 20
 $this.CBStock.top =  $this.CBtoBuy.bottom
 $this.CBStock.left = 10
 $this.CBStock.text = "In Stock Only"
 $this.CBStock.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",10
 $this.controls.add($this.CBStock)
 $this.CBStock.add_click({load_data })

$this.addhint($this.CBStock, "Filter to see only commodities in Stock (when docked only)")

 $this.Bgo = $this.addbutton({if ($GLOBAL:depotName -ne "*ALL*") {display-griddata $editor; $editor.ShowDialog()}},"Edit",0,0)
 $this.Bgo.enabled = $false
 $this.addhint($this.Bgo, "Edit carrier, ship or Active Depot numbers")
 

 $this.Trackerlabel = new-object label
 $this.Trackerlabel.height = 20
 $this.Trackerlabel.top =  0
 $this.Trackerlabel.left =  $this.Bgo.width+ $this.Bgo.left +10
 $this.Trackerlabel.width = 75
 $this.Trackerlabel.text = "Tracker"
 $this.Trackerlabel.TextAlign = "topcenter"
 $this.Trackerlabel.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
 $this.addhint($this.Trackerlabel, "Tracker Status")
 $this.controls.add($this.Trackerlabel )

 $this.TrackerStatus = new-object label
 $this.TrackerStatus.height = 18
 $this.TrackerStatus.top =  $this.Trackerlabel.bottom
 $this.TrackerStatus.left =  $this.Trackerlabel.left
 $this.TrackerStatus.width = 75
 $this.TrackerStatus.text = "Tracker"
 $this.TrackerStatus.TextAlign = "topcenter"
 $this.TrackerStatus.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
 $this.addhint($this.TrackerStatus, "Tracker Status")
 $this.controls.add($this.TrackerStatus)

 $this.summary1 = new-object label
 $this.summary1.height = 25
 $this.summary1.top =  0
 $this.summary1.left =  $this.TrackerStatus.width+ $this.TrackerStatus.left +10
 $this.summary1.width = 400
 $this.summary1.text = "Comment"
 $this.summary1.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
  $this.addhint($this.summary1, "Overall delivery or buy progress")
 $this.controls.add($this.Summary1)

 $this.summary2 = new-object label
 $this.summary2.height = $this.summary1.height
 $this.summary2.top =  $this.summary1.bottom
 $this.summary2.left =  $this.summary1.left
 $this.summary2.width = $this.summary1.width
 $this.summary2.text = "Status - nothing to report"
 $this.summary2.Font = $this.summary1.Font 
 $this.addhint($this.summary2, "Current Journal File ID")
  $this.controls.add($this.Summary2)

$this.depotchooser = new-object combobox
$this.depotchooser.font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",13
$this.depotchooser.top =  $this.summary1.top
$this.depotchooser.left =  $this.summary1.right
#$this.depotchooser.height =  $this.summary1.height *2
$this.depotchooser.width = 400
$this.depotchooser.dropdownstyle =  [System.Windows.Forms.ComboBoxStyle]::DropDownList
$this.depotchooser.add_SelectedIndexChanged({Change-Depot})
$this.addhint($this.depotchooser, "Active Depot Selector")
$this.controls.add($this.depotchooser)

 $this.depotsystem = new-object label
# $this.depotsystem.height = 20
 $this.depotsystem.top =  $this.depotchooser.bottom
 $this.depotsystem.left =  $this.depotchooser.left 
 $this.depotsystem.width = $this.depotchooser.width
 $this.depotsystem.text = "Depot Star System"
 #$this.depotsystem.TextAlign = "topcenter"
 $this.depotsystem.Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",11
 $this.addhint($this.depotsystem, "Depot Star System")
 $this.depotsystem.add_DoubleClick({if ($this.text -gt "") {Set-Clipboard ($this.text)}})
 $this.controls.add($this.depotsystem )

$this.Bdelete = $this.addbutton({delete-depot},"X",1,0,"Archive current Depot")
$this.Bdelete.left = $this.depotchooser.right+3
$this.Bdelete.height = 30
$this.Bdelete.width = 30
$this.Bdelete.forecolor = "black"
$this.Bdelete.backcolor = "Red"
#$this.width = $this.Bdelete.right+300
 $this.LVTable = new-object ListView
 $this.LVTable.font = $fontb
 $this.LVTable.width = $this.width-20
 $this.LVTable.height = $this.height-230
 $this.LVTable.top =  $this.CBStock.bottom+2
 $this.LVTable.height = $this.height- $this.LVTable.top -50
 $this.LVTable.left = 0
 $this.LVTable.gridlines = $true
 $this.LVTable.View  =  [System.Windows.Forms.View]::Details
 $this.LVtable.BackColor = "black"
 $this.LVtable.ForeColor = "white"
 $this.controls.add($this.LVTable)
 $this.LVTable.Add_ItemActivate({CopyToClipboard})
 $this.LVTable.add_ColumnClick({SortListView $this $_.column})
  $this.LVtable.ownerdraw = $true
 $this.LVtable.add_DrawColumnHeader({param ($s,$e)  $e.drawtext() } )
 $this.LVTable.add_DrawSubItem({ param ($s,$e) 
                                $box = $e.Bounds
                                $brush = [solidBrush]::new($e.item.backcolor)
                                $e.Graphics.FillRectangle($brush ,$box)
                                if ($e.columnindex -eq 8) {
                                    $valueString = $e.subitem.tag
                                    draw_bargraph $e $valuestring
                                     $e.SubItem.ForeColor = [color]::White;$e.drawtext([TextFormatFlags]::NoPadding)
                                       } else {  $e.SubItem.ForeColor = $e.item.ForeColor;$e.drawtext([TextFormatFlags]::NoPadding)}
                                 
                                 } 
                                )

   }

}

Function draw_bargraph ($e, $valuestring) {
                                    $values = $valuestring -split ","
                                    $need = $values[2]
                                    $have = $values[1]
                                    $delivered = $values[0]
                                    $brush = [Brushes]::gray
                                    $box.y = $e.Bounds.y +7
                                    $box.Height = $e.Bounds.height -14
                                    $brush = [Brushes]::dimgray
                                    $e.Graphics.FillRectangle($brush ,$box)
                                    
                                    $brush = [Brushes]::DarkOrange  
                                    $box.width = $e.bounds.width * $have/$need
                                    $e.Graphics.FillRectangle($brush ,$box)
                                    $brush = [Brushes]::Green
                                    $box.width = $e.bounds.width * $delivered/$need
                                    $e.Graphics.FillRectangle($brush ,$box)

                                    $lineX = $e.Bounds.x+$e.Bounds.width/2
                                    $lineY1 = $e.Bounds.y
                                    $lineY2 = $e.Bounds.y+$e.bounds.height
                                    $e.Graphics.DrawLine([pens]::gray,$lineX,$lineY1,$lineX,$lineY2)
}

Function SortListView ([object]$LV,$Column) {
    Write-host ASK SORT $Column last was $GLOBAL:lastSortCol
    if ($column -eq $GLOBAL:lastSortCol) {$GLOBAL:sortOrder = !$GLOBAL:sortOrder } else {$GLOBAL:sortOrder =$true}
    $GLOBAL:lastSortCol = $column
 #   $LV.BeginUpdate()
    try {$Numeric = $true;$LV.items|foreach {[single]$X = $_.subitems[$Column].text} } catch {$Numeric = $false}
    if ($numeric) {
                $Newitems = $LV.items |sort -Property @{Expression={[single]$_.subitems[$Column].text};Ascending=$Global:sortOrder } |foreach { $_}
             } else {
                $Newitems = $LV.items |sort -Property @{Expression={$_.subitems[$Column].text};Ascending=$Global:sortOrder } |foreach { $_}
             }
    $totalrow = $Newitems |where {$_.text -ieq "*Total*"}
    $LV.items.clear()
    $Newitems  |where {$_.text -ine "*Total*"} |foreach {$item = $LV.items.add($_)}
    $item = $LV.items.add($totalrow)
  }

function calculate-sum ([int64[]]$nums) {
    $s = 0
    $nums |foreach {$s = $S + $_}
    $S
}

function calculate-totals_original ($values)  {  #this did not account for the carrier carrying more than needed 
    $totals = [TProgressRow]::new()
    $totals.name = "*TOTAL*"
    $totals.type = "*TOTAL*"
    $totals.ship = calculate-sum ($values.ship) 
    $totals.required = calculate-sum ($values.required)
    $totals.Delivered = calculate-sum ($values.Delivered)
    $totals.Carrier = calculate-sum ($values.Carrier)
    $totals.Remaining = calculate-sum ($values.Remaining)
    $totals
}
function calculate-totals ($values)  { #-force total carrier holding to only count whats needed for current depot
    $totals = [TProgressRow]::new()
    $totals.name = "*TOTAL*"
    $totals.type = "*TOTAL*"
    $totals.ship = calculate-sum ($values.ship) 
    $totals.required = calculate-sum ($values.required)
    $totals.Delivered = calculate-sum ($values.Delivered)
    $totals.Carrier = calculate-sum ($values.Carrier)
    $totals.Remaining = calculate-sum ($values.Remaining)
    $haveTotal = 0
     $values |foreach  {
         $have = $_.carrier +$_.ship
         $need = $_.required - $_.Delivered

         if ($have -gt $need) {$have = $need}
         $haveTotal = $haveTotal +$have
     }
    
     $totals.Carrier = $haveTotal - $totals.ship
     if ($totals.Carrier -lt 0) {$totals.Carrier = 0}

    $totals
}

function load_data  {

    $instockTypes = [hashtable]::new()
    if ($marketData -ne $null) {$marketData.Items|where {$_.stock -gt 0}  |foreach {$M = $_.name -match '\$(.*)_name';$type = $matches[1];$instockTypes.add($type,$_.stock)}} #

    $table.LVTable.Clear()
    $totals = calculate-totals $global:proghash.values
    if ($table.CBFilter.Checked) {$Rows = $global:proghash.values |where {$_.required -gt $_.delivered}} else {$Rows = $global:proghash.values}
    if ($table.CBtobuy.Checked) {$Rows = $global:proghash.values |where {$_.required -gt ($_.delivered+$_.ship+$_.carrier)}}
    if ($table.CBStock.Checked) {
        if ($marketData -ne $null) {
                $Rows = $Rows |where {$_.type -in $instockTypes.keys}}
        }
    $rows = @($rows|sort name ) + $totals
    if ($rows -ne $null) {
        
         $cols = @("Name",'Stock',"Required","Delivered","Ship","Carrier","Remaining","Notes","Progress")
         $cols |foreach {$obj = $table.LVTable.columns.add($_,-2)}
         $table.LVTable.ForeColor = "white"
             $Rows|foreach {
             $D = $_
             $type = $D.type
             if ($type -in $instockTypes.keys) {$stock = $instockTypes.$type} else {$stock = ""}
             $text = [string]($D.Name)
             $I = new-object Listviewitem($text)
           $obj = $I.Font = $fontB             
           $obj = $I.SubItems.add($stock) 
           $obj = $I.SubItems.add($D.required) 
           $obj = $I.SubItems.add($D.Delivered)  
           $obj = $I.SubItems.add($D.ship)       
           $obj = $I.SubItems.add($D.Carrier)                 
           $obj = $I.SubItems.add($D.Remaining) 
             $notes = ""
             $color = "White"
             $backColor = "Black"          

             [int64]$ship = $D.ship
             [int64]$carrier = $D.carrier
             [int64]$remaining = $D.remaining
             [int64]$buy = $D.required - $D.Delivered - $D.ship - $D.Carrier
             if (($buy) -gt 0) {$notes = "Buy $Buy"}
             if (($ship+$Carrier) -ge $Remaining) {$notes = "Enough bought";$color = "Orange"}
             if (($Carrier) -ge $Remaining) {$notes = "Enough On Carrier";$color = "Yellow"}
             if (($Ship) -eq $Remaining) {$notes = "Enough On Ship";$color = "lightBlue"}
             if (($Remaining) -le 0) {$notes = "Complete";$color = "lightGreen"}  
             if ($stock -gt 0) {$Backcolor = "darkBlue"}
             if ($ship -gt $remaining) {$notes = "Excess supply"; $color = "White";$Backcolor = "darkRed"}
             if ($D.required -eq 0) {$notes = "Extra"; $color = "magenta";$Backcolor = "black"}
             if ($text -eq "*TOTAL*") {$color = "AntiqueWhite";$Backcolor = "DarkSlateGray"}
              $I.ForeColor = $color
              $I.BackColor = $backColor
              $obj = $I.SubItems.add($notes) 
              $Bought = $D.carrier + $D.Ship +$D.delivered
              if ($Bought -gt $D.required) {$Bought = $D.required}
               $delivered = $D.delivered
               $required = $D.required
               if ($table.CBtobuy.Checked) { $Quantity = $bought} else {$Quantity = $delivered}
               $progress ="{0,3}" -f ([int64]($Quantity/$required*100))
              $obj = $I.SubItems.add($progress)  
              $obj.tag = "$delivered,$Bought,$Required"
               $obj =$table.LVTable.items.add($I)

             }
        $table.LVtable.Columns|foreach {$_.width = $defaultColumnWidth}
        $table.LVtable.Columns[0].AutoResize(2);$table.LVtable.Columns[0].width = $table.LVtable.Columns[0].width + 20
        if ($marketData -ne $null) { $table.LVtable.Columns[1].AutoResize(2);$table.LVtable.Columns[1].width = $table.LVtable.Columns[1].width + 20} else {$table.LVtable.Columns[1].width = 0}
        $table.LVtable.Columns[7].AutoResize(2);$table.LVtable.Columns[7].width = $table.LVtable.Columns[7].width + 20
        $table.LVtable.Columns[8].width = $defaultColumnWidth*2
    } else {$table.LVTable.columns.add("Nothing to show",500,'center')} 

     if ($GLOBAL:lastSortCol -gt 0) {$resort = $GLOBAL:lastSortCol;$GLOBAL:lastSortCol = -1;SortListView $table.LVTable $resort}
     $all = $global:proghash.values 
     $allbuy = $all |where {($_.ship+$_.carrier) -lt $_.remaining}
     $TotDeliver = (sum $All.remaining)
     $TotBuy = (sum $Allbuy.remaining) - (sum $allbuy.ship) -(sum $allbuy.carrier)
     if ($cargoSize -gt 0) {
             $runsDeliver = "needing "+ [math]::Ceiling($totDeliver/$cargoSize) + " trips."
             $runsBuy = "needing "+ [math]::Ceiling($totBuy/$cargoSize) + " trips."
             } else {$runsDeliver=""; $runsBuy =""}
     if ($table.CBtobuy.Checked) {$table.summary1.text = "$totBuy to buy $runsBuy"} else
                                 {$table.summary1.text = "$totDeliver to deliver $runsDeliver"}
     }

$homedir = "C:\data\Scripts\Colonise\"
$progressfile = $homedir+"Progress.csv"
 $lastWrite = $null


function get-progress {

    $pf = Get-ChildItem ($progressdir+"*.json") |sort LastWriteTime |select -last 1
    $sf = get-item $statusfile
     if (test-path $marketfile) {$mf = get-item $marketfile} else {$mf = $null;$marketData = $null}

    if ($sf.LastWriteTime -ne $GLOBAL:lastStatus) {
        $StatusJson = Get-Content $statusfile
        $status = ConvertFrom-Json "$StatusJson"
        $txt = $status.comment.replace("Journal.","").replace(".log","")
        $txt = $txt.replace("Planetary Construction Site:","PCS")
        $txt = $txt.replace("Orbital Construction Site:","OCS")
        $txt = $txt.replace("System Colonisation Ship","SCS")
        $table.summary2.text = $txt
        $GLOBAL:TrackerPID = $status.processID
        $GLOBAL:cargosize = $status.CargoCapacity
        $GLOBAL:Padsize = $status.pad
        $GLOBAL:StarSystem = $status.StarSystem
      $GLOBAL:lastStatus = $sf.LastWriteTime 

    }

    if ($mf.LastWriteTime -ne $GLOBAL:lastMarket) {
       if ($mf -ne $null) {$MarketJson = Get-Content $Marketfile
                            $GLOBAL:marketData = ConvertFrom-Json "$MarketJson"
                            } else {$GLOBAL:marketData = $null}
        load_data $progHash
        $GLOBAL:lastMarket = $mf.LastWriteTime 
    }
    
    if ($pf.LastWriteTime -ne $GLOBAL:lastWrite) {
      # clear
        write-host ($pf.LastWriteTime)
        #reload the list of depots
        $index = $table.depotchooser.SelectedIndex
        $depotfiles = @(Get-ChildItem ($progressDir+"*.json") |where {$_.name -notlike "_*"} |sort name)
        $table.depotchooser.items.clear()
        $GLOBAL:depotnames = $depotfiles |foreach {$_.name.replace(".json","")}
        $GLOBAL:depotnames|foreach {$table.depotchooser.items.add($_)}
        get-DepotStarsystems |foreach {$group = "*"+$_+"*";$table.depotchooser.items.add($group)}
        $table.depotchooser.items.add("*ALL*")
        if ($index -ge $table.depotchooser.items.count) {$index =$table.depotchooser.items.count-1}
        $table.depotchooser.SelectedIndex = $index 
      
       $GLOBAL:proghash = load-progress
       $progress = $GLOBAL:proghash.values |sort name
       $progress
       $totdel = sum $progress.delivered
       $totreq = sum $progress.required
       if ($totreq -gt 0) { $pc = [math]::round($totdel/$totreq*100,1)} else {$pc = 0}
    #   write-host total: $totreq delivered: $totdel $pc%
        $GLOBAL:lastWrite = $pf.LastWriteTime 
       load_data $progHash
       }

     $trackerProcess = get-process -id $GLOBAL:TrackerPID -ErrorAction SilentlyContinue
     if ($trackerProcess.name -match "powershell") {$tracktext = "OK";$trackcolor = "lightGreen"} else {$tracktext = "OFF";$trackColor="Pink"}
       $table.TrackerStatus.text = $tracktext
       $table.TrackerStatus.ForeColor = $trackcolor
       
      
}


Function add-row  {
   $newList = $ConstructionCommodities.commodities |where {$_.name -notin $GLOBAL:proghash.Values.name}
   $FormCS.Load($newlist.name)
   if ($FormCS.showdialog() -eq [dialogresult]::Ok)  {
        $FormCS.LBcommodities.SelectedIndices |foreach {
            $i = $_
            $newRow = [TprogressRow]::new()
            $name = $newList[$i].name
            $type = $newList[$i].type
            $newrow.name = $name
            $newrow.type = $type
            Write-host $i ($newRow.name) ($newrow.Type)
            $GLOBAL:proghash.add($newrow.type,$newrow)
            $newcdty = [Tcommodity]::new()
            $newcdty.name = $name
            $newcdty.type = $type
            $GLOBAL:Depot.hash.add($type,$newcdty)
            
            }
        display-griddata $editor
   } 
}

Function Delete-row  {
    $editor.grid.SelectedRows |foreach  {
    $type = $editor.grid.SelectedRows.cells[1].Value
    $global:proghash.remove($type)
    $global:depot.hash.remove($type)

    }
 display-griddata $editor
}


class Commodity_selector : Form {

 [button] $Bok
 [button] $Bcancel
 [listBox] $LBcommodities

  
 load ([System.Collections.ArrayList]$list) {
    $this.LBcommodities.Items.clear()
    $list|foreach  {$X = $this.LBcommodities.Items.Add($_) }
   # $this.LBcommodities.SelectedIndex = 0
    
 }

######################################################################################################
#   Commodity Selector
######################################################################################################

 Commodity_selector () {
 $this.width = 650
 $this.height = 800
 $this.text = "Select mineral"

 $buttonstart = $this.height -120
 $font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",12
 
 $this.LBcommodities = new-object ListBox
 $this.LBcommodities.width = $this.width-40
 $this.LBcommodities.height = $this.height -150
 $this.LBcommodities.top = 30
 $this.LBcommodities.left = 10
 $this.LBcommodities.Font = new-object system.drawing.font -ArgumentList "Courier New",12
 $this.LBcommodities.enabled = $true
 $this.LBcommodities.SelectionMode = "Multisimple"
 $this.controls.add($this.LBcommodities)


 $this.Bcancel = new-object button
 $this.Bcancel.width = 100
 $this.Bcancel.height = 40
 $this.Bcancel.top =  $buttonstart
 $this.Bcancel.left = 10
 $this.Bcancel.text = "Cancel"
 $this.Bcancel.Font = $this.LBminables.Font 
 $this.Bcancel.Dialogresult =[dialogresult]::Cancel
 $this.controls.add($this.Bcancel)

 $this.Bok = new-object button
 $this.Bok.width = 100
 $this.Bok.height = 40
 $this.Bok.top =  $buttonstart
 $this.Bok.left = 100
 $this.Bok.text = "Add"
 $this.Bok.Font = $this.LBminables.Font 
 $this.Bok.Dialogresult =[dialogresult]::Ok
 $this.controls.add($this.Bok)


 $this.cancelButton = $this.Bcancel
 $this.AcceptButton = $this.accept
 
 }
}


######################################################################################################
#   EDITOR GRIDVIEW
######################################################################################################

function display-griddata ($editor){
     $editor.grid.rows.Clear()
      $GLOBAL:proghash.values|sort name| foreach  {
      $r=  $editor.grid.rows.add(($_.name,$_.type,$_.Required,$_.Delivered,$_.ship,$_.Carrier,$_.remaining))
   $r= $editor.grid.rows |foreach {
                    $bc = "black"
                    $fc = "white"
                    if ($_.cells[6].value -eq 0) { $fc = "green"}
                    if (($_.cells[5].value+$_.cells[4].value) -gt $_.cells[6].value) { $fc = "yellow"}
                    $_.DefaultCellStyle.backcolor = $bc
                    $_.DefaultCellStyle.ForeColor = $fc
                    }
    }

}

function save-griddata {
        Write-host SAVE DATA 
        $editor.grid.rows | where {$_.cells[1].value -ne $null} | Foreach  {
                $row = $_
                $type = $row.cells[1].value
             #   write-host Get data for $type
                [int64]$req = $row.cells[2].value
                [int64]$del = $row.cells[3].value
                [int64]$shi = $row.cells[4].value
                [int64]$car = $row.cells[5].value
                [int64]$rem = $row.cells[6].value

                $GLOBAL:proghash.$type.Required = $req
                $GLOBAL:Depot.hash.$type.required = $req

                $GLOBAL:proghash.$type.Delivered = $del
                $GLOBAL:Depot.hash.$type.have = $del

                $GLOBAL:proghash.$type.ship = $shi
                $GLOBAL:Ship.hash.$type.have = $shi

                $GLOBAL:proghash.$type.carrier= $car
                $GLOBAL:carrier.hash.$type.have = $car

                $GLOBAL:proghash.$type.Remaining = $rem
                }

            save-progress


        }

function load-carrier {
    $rawlines = get-clipboard
            #trim pre-table lines
            $TSV = [System.Collections.Generic.List[string]]::new()
            $rawlines |foreach {if ($_ -match "^.*Cr.*CR$|^Commodities	Value	Qty	Total") {$tsv.ADD($_)} }
            if ($TSV.Count -gt 0) {
                $TSV[0] = $TSV[0].replace("Commodities","Name")
              #  $TSV =$TSV.replace(",","").replace(" ","").ToLower()

                $cargoArray = $TSV |convertFrom-csv -Delimiter "`t" |select Name,Qty
                $cargo = [hashtable]::New()
                $cargoArray |foreach {$cargo.add($_.name.tolower(),$_.qty)}
                foreach ($row in $editor.grid.rows) {
                        $t = $row.cells[0].value
                        if ($t -ne $null) {$t = $t.tolower()
                            if ($t -in $cargo.keys) {$row.cells[5].value= $cargo.$t} else {$row.cells[5].value=0}
                            }
                }
            }
}


function cell-change ($s,$c,$r){
[int64]$value = $s.rows[$r].cells[$c].value
if ($c -in (2,3)) {$remain = $s.rows[$r].cells[2].value - $s.rows[$r].cells[3].value ; $s.rows[$r].cells[6].value = $remain}
if ($c -in (7)) { $s.rows[$r].cells[3].value = $s.rows[$r].cells[3].value + $value; $s.rows[$r].cells[7].value = ""}
if ($c -in (6)) {$Delivered = $s.rows[$r].cells[2].value - $s.rows[$r].cells[6].value ; $s.rows[$r].cells[3].value = $delivered}
} 

function cell-validating ($s,$e){
    $c = $e.columnindex
    $r = $e.rowindex
 <#   if ($c -in (0,1)) {$ret = $false} ELSE {
        try {   $string =  $s.rows[$r].cells[$c].value
                [int64]$value = $string
                if ($c -in (2..6)) {$ret = !($value -in (0..10000000))}
                if ($c -in (7)) {$ret = !($value -in (-1000..1000))}
            } catch {$ret= $true}
         }
    $ret
    write-host $ret #>
}
 #################################################################
 #  CLASS Tgrid (editor)
 ##################################################################

class Tgrid: Form {

[datagridview]$Grid

[button]AddButton([System.EventHandler]$action,$text,$x,$y ){
     $Button = new-object button
     $Button.width = 130
     $Button.height = 30
     $Button.top = 3 +$y*($Button.height+10)
     $Button.left = 10 + $x*($Button.width+10) +$this.CBFilter.left +$this.CBFilter.width  
     $Button.text = $text
     $Button.add_click($action)
     $this.controls.add($Button)
     $needwidth = $Button.left + $Button.width + 20
     if ($this.width -lt $needwidth  ) {$this.width = $needwidth }
     return $button
}  
[button]AddButton([System.EventHandler]$action,$text,$x,$y,$hint ){
     $Button = $this.addButton($action,$text,$x,$y)
     $tt = [tooltip]::new()
     $tt.SetToolTip($Button, $hint)
     return $button
} 
Doresize ($o) {
     $o.width = $this.width -50
     $o.height = $this.height -$this.grid.top-60
}

Tgrid () {


 
 $Font = new-object system.drawing.font -ArgumentList "Microsoft Sans Serif",14

 $FontB = new-object system.drawing.font -ArgumentList $font,"Bold"
 $this.font = $Font
 $this.width = 900
 $this.height = 800

 $This.addbutton({display-griddata $this.parent},"Reload",0,0)
 $This.addbutton({save-griddata},"Save",1,0)
 $This.addbutton({load-carrier},"Paste Carrier",2,0,"Clipboard must contain copy of Inara Carrier cargo page")
 $This.addbutton({Add-Row},"Add row",0,1,"Add more commodities to this template")
 $This.addbutton({Delete-Row},"Delete row",1,1,"Delete selected commodities from this template")
 $this.text = "Colonisation Progress File Editor"

 $this.grid = [datagridview]::new() 
 $this.grid.top = 80
 $this.grid.width = $this.width -50
 $this.grid.height = $this.height -$this.grid.top-60
 $headings = ("Name","Type","Required","Delivered","Ship","Carrier","Remaining","(+/-)")
 $this.grid.ColumnCount = $headings.count
  (0..($headings.count-1)) |foreach {$this.grid.Columns[$_].name = $headings[$_]}

  $this.grid.Add_CellValueChanged({ param ($s,$e); 
                                    Cell-change $s $e.columnindex $e.rowindex})
  $this.grid.Add_CellValidating({ param ($s,$e); 
                                   $e.cancel = (Cell-validating $s $e)})

 $this.controls.add($this.grid)

 $this.grid.ColumnHeadersHeight = 40
 $this.grid.Columns[0].width = 300
 $this.grid.Columns[1].width = 0
 $this.grid.Columns[4].width = 70
 $this.grid.Columns[5].width = 70
 $this.grid.Columns[0].readonly = $true
 $this.grid.Columns[1].readonly = $true
 $this.add_resize({$this.DoResize( $this.grid)})

 Display-griddata $this

 }
 }

 $editor= new-object TGrid
 #$editor.ShowDialog()

$json = get-content ($templateDir+"_ConstructionCommodities.json")
$ConstructionCommodities = convertfrom-json "$json"
$FormCS = [Commodity_selector]::new()

$table= new-object Ttable 
$depotfiles = Get-ChildItem ($progressDir+"*.json") |where {$_.name -notlike "_*"} |sort name
$table.depotchooser.items.clear()
$GLOBAL:depotnames = $depotfiles |foreach {$_.name.replace(".json","")}
$GLOBAL:depotnames|foreach {$table.depotchooser.items.add($_)}
$table.depotchooser.items.add("*ALL*")
$Statusjson = get-content $statusFile
$status = convertfrom-json "$StatusJson"
  if (test-path $settingsFile) {
          $json = get-content $settingsFile
          $settings = convertfrom-json "$Json"
          } else {$settings = [Tsettings]::new() }
$Index = $table.depotchooser.items.IndexOf($settings.ActiveDepot)
if ($index -lt 0) {$index = 0;$settings.ActiveDepot = $table.depotchooser.items[$index]}
$table.depotchooser.SelectedIndex = $Index

$GLOBAL:depotName = $table.depotchooser.SelectedItem
$global:proghash = load-progress
load_data

$timer = New-Object System.Windows.Forms.Timer
$timer.stop()
  $timer.Interval = 1000
  $timer.add_tick({get-progress; })
$timer.Start()
$Button = $table.Showdialog()  
$timer.stop()
  