﻿# This script will make the shortcuts to launch Dart's Colonisation scripts with required assempbly type added and correct path to script location
# This script MUST be run while located in the same, final location as the 3 scripts
# the shortcuts are then installed into the subdirectory 'shortcuts' -move them to your preferred location

$scriptpath =$MyInvocation.MyCommand.Path
$scriptDir = (split-path $scriptpath )
$scriptcmd = 'powershell.exe'
if (!(test-path shortcuts)) {mkdir shortcuts}

$MonArg ="using namespace System.Windows.Forms;add-type -AssemblyName  System.Windows.Forms; . $scriptdir\ColoniseMonitorGUIV2.ps1"
$TrkArg ="using namespace System.Windows.Forms;add-type -AssemblyName  System.Windows.Forms; . $scriptdir\ColoniseTrackerjobV2.ps1"
$TmpArg ="using namespace System.Windows.Forms;add-type -AssemblyName  System.Windows.Forms; . $scriptdir\ColonisemakeTemplatesV2.ps1"

$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$scriptdir\shortcuts\Colonisation Monitor.lnk")
$Shortcut.TargetPath = $scriptcmd
$shortcut.Arguments = "-c ""$MonArg"""
$Shortcut.Save()

$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$scriptdir\shortcuts\Colonisation Tracker.lnk")
$Shortcut.TargetPath = $scriptcmd
$shortcut.Arguments = "-c ""$TrkArg"""
$Shortcut.Save()

$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$scriptdir\shortcuts\Colonisation Templates.lnk")
$Shortcut.TargetPath = $scriptcmd
$shortcut.Arguments = "-c ""$TmpArg"""
$Shortcut.Save()